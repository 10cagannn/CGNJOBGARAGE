Config = {}

Config.Garages = {
    police = {
        spawn = { coords = vector3(457.92, -990.31, 25.7), heading = 90.0 },
        npc = { model = "s_m_y_cop_01", coords = vector4(460.11, -986.67, 25.7, 81.84) },
        vehicles = {
            {label = "Dodge Charger", model = "npolchar", livery = 0},
            {label = "Ford Victoria", model = "npolvic", livery = 0},
            {label = "Ford Explorer", model = "npolexp", livery = 0}
        }
    },
    state = {
        spawn = { coords = vector3(848.87, -1327.39, 26.18), heading = 26.18 },
        npc = { model = "s_m_y_hwaycop_01", coords = vector4(841.07, -1315.3, 26.24, 185.46) },
        vehicles = {
            {label = "Dodge Charger", model = "npolchar", livery = 0},
            {label = "Ford Victoria", model = "npolvic", livery = 0},
            {label = "Ford Explorer", model = "npolexp", livery = 0} 
        }
    },
    sheriff = {
        spawn = { coords = vector3(1863.42, 3674.57, 33.8), heading = 33.8 },
        npc = { model = "s_m_y_sheriff_01", coords = vector4(1863.63, 3683.17, 33.77, 206.14) },
        vehicles = {
            {label = "Dodge Charger", model = "npolchar", livery = 0},
            {label = "Ford Victoria", model = "npolvic", livery = 0},
            {label = "Ford Explorer", model = "npolexp", livery = 0} 
        }
    }
}
