local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent("policegarage:saveVehicle", function(vehicleProps)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        local citizenid = Player.PlayerData.citizenid
        local plate = vehicleProps.plate
        local model = vehicleProps.model

        
        MySQL.insert('INSERT INTO player_vehicles (license, citizenid, vehicle, hash, mods, plate, state, garage) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE mods = ?, state = ?',
        {
            Player.PlayerData.license,
            citizenid,
            model,
            model,
            json.encode(vehicleProps),
            plate,
            0, 
            "personal", 
            json.encode(vehicleProps),
            0
        }, function(affectedRows)
            if affectedRows and affectedRows > 0 then
                print(("Araç başarıyla kaydedildi! Oyuncu: %s, Plaka: %s"):format(citizenid, plate))
            else
                print("Araç kaydı başarısız!")
            end
        end)
    else
        print("Oyuncu bulunamadı, araç kaydedilemedi!")
    end
end)
RegisterNetEvent("policegarage:logSpawn", function(data, plate)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local name = Player.PlayerData.charinfo.firstname .. " " .. Player.PlayerData.charinfo.lastname
    local job = Player.PlayerData.job.name
    local citizenid = Player.PlayerData.citizenid

    local message = string.format("🚓 **Polis Garajı Logu**\n\n👤 **İsim:** %s\n📋 **CitizenID:** %s\n🔰 **Görev:** %s\n🚗 **Araç:** %s\n📄 **Plaka:** %s", name, citizenid, job, data.label, plate)

    local webhook = "https://discord.com/api/webhooks/1396300222308810813/oPPmnQ8GqQLV0413HeBbjRKeuhJop4o4lu0CPZq3EoMPrOKA_Qi3wARGre2BZ9Vf_xsf" -- <- bunu kendin ayarlamalısın

    PerformHttpRequest(webhook, function(err, text, headers) end, "POST", json.encode({
        username = "Police Garage Logs",
        embeds = {{
            title = "Yeni Polis Aracı Çıkartıldı",
            description = message,
            color = 3447003,
            footer = { text = os.date("%d.%m.%Y %H:%M:%S") }
        }}
    }), { ["Content-Type"] = "application/json" })
end)
