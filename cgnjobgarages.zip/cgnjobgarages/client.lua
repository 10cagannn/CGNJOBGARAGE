local QBCore = exports['qb-core']:GetCoreObject()

function SpawnGarageNPC(job)
    local cfg = Config.Garages[job]
    if not cfg then return end

    local model = cfg.npc.model
    local coords = cfg.npc.coords

    RequestModel(GetHashKey(model))
    while not HasModelLoaded(GetHashKey(model)) do
        Wait(10)
    end

    local npc = CreatePed(4, GetHashKey(model), coords.x, coords.y, coords.z - 1.0, coords.w, false, true)
    SetEntityInvincible(npc, true)
    SetBlockingOfNonTemporaryEvents(npc, true)
    FreezeEntityPosition(npc, true)
    SetPedCanRagdoll(npc, false)

    exports['qb-target']:AddTargetEntity(npc, {
        options = {
            {
                icon = "fas fa-car",
                label = "Araç Menüsünü Aç",
                action = function()
                    local PlayerData = QBCore.Functions.GetPlayerData()
                    if PlayerData.job and PlayerData.job.name == job then
                        local vehs = {}
                        for _, v in ipairs(cfg.vehicles) do
                            table.insert(vehs, {
                                header = v.label,
                                txt = "Aracı seç",
                                params = {
                                    event = "garage:trySpawnVehicle",
                                    args = { data = v, job = job }
                                }
                            })
                        end
                        exports['qb-menu']:openMenu(vehs)
                    else
                        QBCore.Functions.Notify("Bu menüyü açma yetkin yok.", "error")
                    end
                end,
                canInteract = function()
                    local PlayerData = QBCore.Functions.GetPlayerData()
                    return PlayerData.job and PlayerData.job.name == job
                end
            }
        },
        distance = 2.5
    })
end

RegisterNetEvent("garage:trySpawnVehicle", function(args)
    local job = args.job
    local data = args.data
    local cfg = Config.Garages[job]
    if not cfg then return end

    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)

    local vehicle = GetClosestVehicle(pos.x, pos.y, pos.z, 5.0, 0, 70)
    if DoesEntityExist(vehicle) then
        QBCore.Functions.Notify("Yakında başka araç var!", "error")
        return
    end

    QBCore.Functions.Notify(data.label .. " hazırlanıyor...", "primary")

    local citizenid = QBCore.Functions.GetPlayerData().citizenid
    local plate = string.upper(string.sub(citizenid, 1, 3)) .. tostring(math.random(100, 999))

    QBCore.Functions.SpawnVehicle(data.model, function(vehicle)
        SetEntityCoords(vehicle, cfg.spawn.coords.x, cfg.spawn.coords.y, cfg.spawn.coords.z, false, false, false, true)
        SetEntityHeading(vehicle, cfg.spawn.heading)
        SetVehicleNumberPlateText(vehicle, plate)
        SetVehicleLivery(vehicle, data.livery or 0)
        TaskWarpPedIntoVehicle(ped, vehicle, -1)

        TriggerEvent("vehiclekeys:client:SetOwner", plate)
        TriggerServerEvent("garage:logSpawn", data, plate)

        local props = QBCore.Functions.GetVehicleProperties(vehicle)
        props.plate = plate
        props.model = data.model

        TriggerServerEvent("policegarage:saveVehicle", props)
    end)
end)


CreateThread(function()
    for job, _ in pairs(Config.Garages) do
        SpawnGarageNPC(job)
    end
end)


